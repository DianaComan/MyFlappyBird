#include "Tema1.h"
#include <vector>
#include <iostream>
#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"

using namespace std;

Tema1::Tema1()
{
}

Tema1::~Tema1()
{
}

void Tema1::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	glm::vec3 corner = glm::vec3(0, 0, 0);
	float squareSide = 100;
	gameover == 0;
	n = 0;
	n1 = 0;
	n2 = 0;
	n3 = 0;
	n4 = 0;
	gameover = 0;
	varprint = 3;
	// compute coordinates of square center
	float cx = corner.x + squareSide / 2;
	float cy = corner.y + squareSide / 2;
	
	// initialize tx and ty (the translation steps)
	translateX = 1500;
	translateY = 590;

	for (int i = 0; i <= 4; i++) {
		y[i] = rand() % 5;
		y1[i] = 8 - y[i] - rand() % 3;
	}
	limitup = 590 - y[0] * 50;
	limitdown = 100 + y1[0] * 50;
	limitindex = 0;
	limitx = 1500;
	a[0] = 100; a[1] = 155; a[2] = 170;
	b[0] = 270; b[1] = 290; b[2] = 230;
	aux1 = b[0];


	// initialize sx and sy (the scale factors)
	scaleX = 1;
	scaleY = 1;
	
	// initialize angularStep
	angularStep = 0;

	Mesh* square3 = Object2D::CreateSquare("square3", corner, 10, glm::vec3(0, 1, 1), true);
	AddMeshToList(square3);

	Mesh* pipe1 = Object2D::CreateSquare("pipe1", corner, 50, glm::vec3(0, 1, 1), true);
	AddMeshToList(pipe1);

	Mesh* sq = Object2D::CreateSquare("s1", corner, 40, glm::vec3(0, 1, 1), true);
	AddMeshToList(sq);

	Mesh* bird = Object2D::CreateBird("t", corner, 50, glm::vec3(0, 1, 1), true);
	AddMeshToList(bird);

	{
		vector<VertexFormat> vertices3;
		vector<unsigned short> indices3;
		vertices3.push_back(VertexFormat(glm::vec3(0, 1, 1), glm::vec3(0, 1, 1)));
		for (int i = 0; i <= 359; ++i) {
			VertexFormat aux = VertexFormat(glm::vec3(20*cos(2 * M_PI * i / 359), 20*sin(2 * M_PI * i / 359), 0), glm::vec3(0, 1, 1));
			vertices3.push_back(aux);
		}

		//vector<unsigned short> indices3;
		for (int i = 0; i <= 359; ++i) {
			indices3.push_back(i);
		}
		indices3.push_back(360);

		meshes["circle1"] = new Mesh("generated circle 1");
		meshes["circle1"]->InitFromData(vertices3, indices3);

		Mesh *circle = CreateMesh("circle1", vertices3, indices3);
		circle->SetDrawMode(GL_TRIANGLE_FAN);
	}

	{
		vector<VertexFormat> vertices2
		{
			VertexFormat(glm::vec3(-2, 0, 1), glm::vec3(1, 0, 0)),
			VertexFormat(glm::vec3(-1, 0, 1), glm::vec3(1, 0, 0)),
			VertexFormat(glm::vec3(-2, 1, 1), glm::vec3(1, 0, 0)),
			VertexFormat(glm::vec3(-1, 1, 1), glm::vec3(1, 0, 0))
		};

		vector<unsigned short> indices2 =
		{
			1, 0, 3,
			2, 0, 3,
		};

		meshes["t1"] = new Mesh("generated t");
		meshes["t1"]->InitFromData(vertices2, indices2);

		Mesh *trinagle = CreateMesh("t1", vertices2, indices2);
	}

}


Mesh* Tema1::CreateMesh(const char *name, const std::vector<VertexFormat> &vertices, const std::vector<unsigned short> &indices)
{
	unsigned int VAO = 0;
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);
	unsigned int VBO = 0;
	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), &vertices[0], GL_STATIC_DRAW);
	unsigned int IBO = 0;
	glGenBuffers(1, &IBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(), &indices[0], GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), 0);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(sizeof(glm::vec3)));
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3)));
	glEnableVertexAttribArray(3);
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3) + sizeof(glm::vec2)));
	glBindVertexArray(0);
	CheckOpenGLError();
	meshes[name] = new Mesh(name);
	meshes[name]->InitFromBuffer(VAO, static_cast<unsigned short>(indices.size()));
	return meshes[name];
}

void Tema1::FrameStart()
{
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Tema1::Update(float deltaTimeSeconds)
{
	angularStep += 1 * deltaTimeSeconds;

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(0, 600);
	modelMatrix *= Transform2D::Scale(200, -1);
	RenderMesh2D(meshes["square3"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(0, 90);
	modelMatrix *= Transform2D::Scale(200, 1);
	RenderMesh2D(meshes["square3"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(1500, 590);
	modelMatrix *= Transform2D::Scale(1, -y[0]);
	translateX = 0 - 150 * (angularStep)+n * 1500;
	if (translateX < -1600) {
		n++;
		y[0] = rand() % 5;
		y1[0] = 8 - y[0] - rand() % 3;
		
	}
	if (translateX < -1500) {
		limitup = 590 - y[1] * 50;
		limitdown = y1[1] * 50 + 100;
		limitindex = 1;
		limitx = 1800;
	}
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(1500, 100);
	modelMatrix *= Transform2D::Scale(1, y1[0]);
	translateX = 0 - 150 * (angularStep)+n * 1500;
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(1800, 590);
	modelMatrix *= Transform2D::Scale(1, -y[1]);
	translateX = 0 - 150 * (angularStep)+n1 * 1500;
	if (translateX < -1900) {
		n1++;
		y[1] = rand() % 5;
		y1[1] = 8 - y[1] - rand() % 3;
	}
	if (translateX < -1800) {
		limitup = 590 - y[2] * 50;
		limitdown = y1[2] * 50 + 100;
		limitindex = 2;
		limitx = 2100;
	}
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(2100, 590);
	modelMatrix *= Transform2D::Scale(1, -y[2]);
	translateX = 0 - 150 * (angularStep)+n2 * 1500;
	if (translateX < -2200) {
		n2++;
		y[2] = rand() % 5;
		y1[2] = 8 - y[2] - rand() % 3;
	}
	if (translateX < -2100) {
		limitup = 590 - y[3] * 50;
		limitdown = y1[3] * 50 + 100;
		limitindex = 3;
		limitx = 2400;
	}
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(2400, 590);
	modelMatrix *= Transform2D::Scale(1, -y[3]);
	translateX = 0 - 150 * (angularStep)+n3 * 1500;
	if (translateX < -2500) {
		n3++;
		y[3] = rand() % 5;
		y1[3] = 8 - y[3] - rand() % 3;
	}
	if (translateX < -2400) {
		limitup = 590 - y[4] * 50;
		limitdown = y1[4] * 50 + 100;
		limitindex = 4;
		limitx = 2700;
	}
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(2700, 590);
	modelMatrix *= Transform2D::Scale(1, -y[4]);
	translateX = 0 - 150 * (angularStep)+n4 * 1500;
	if (translateX < -2800) {
		n4++;
		y[4] = rand() % 5;
		y1[4] = 8 - y[4] - rand() % 3;
	}
	if (translateX < -2700) {
		limitup = 590 - y[0] * 50;
		limitdown = y1[0] * 50 + 100;
		limitindex = 0;
		limitx = 1500;
	}
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(2100, 100);
	modelMatrix *= Transform2D::Scale(1, y1[2]);
	translateX = 0 - 150 * (angularStep)+n2 * 1500;
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(1800, 100);
	modelMatrix *= Transform2D::Scale(1, y1[1]);
	translateX = 0 - 150 * (angularStep)+n1 * 1500;
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);modelMatrix = glm::mat3(1);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(2400, 100);
	modelMatrix *= Transform2D::Scale(1, y1[3]);
	translateX = 0 - 150 * (angularStep)+n3 * 1500;
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(2700, 100);
	modelMatrix *= Transform2D::Scale(1, y1[4]);
	translateX = 0 - 150 * (angularStep)+n4 * 1500;
	modelMatrix *= Transform2D::Translate(translateX, 0);
	RenderMesh2D(meshes["pipe1"], shaders["VertexColor"], modelMatrix);

	float k = angularStep;
	modelMatrix = glm::mat3(1);
	if (okkk == 0) {
		int kkk = 0;
		if (kkk == 0) {
			aux1 = b[0];
			kkk = 1;
		}
		b[0] = aux1 - 1 * (k - int(k) + 1);
	}
	else {
		int kkk = 0;
		if (kkk == 0) {
			aux1 = b[0];
			kkk = 1;
		}
		b[0] = aux1 + 2.5f *(k - int(k) + 1);
	}
	modelMatrix *= Transform2D::Translate(a[0], b[0]);
	modelMatrix *= Transform2D::Scale(0.75f, 0.75f);
	RenderMesh2D(meshes["s1"], shaders["VertexColor"], modelMatrix);
	
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(a[1] - 11, b[0] + 15);
	modelMatrix *= Transform2D::Scale(0.75f, 0.75f);
	RenderMesh2D(meshes["circle1"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(a[1] + 3, b[0] + 10 + 15);
	modelMatrix *= Transform2D::Scale(0.5f, 0.5f);
	modelMatrix *= Transform2D::Rotate(-3.1415 / 2);
	RenderMesh2D(meshes["t"], shaders["VertexColor"], modelMatrix);

	

	
	if ((b[0] > 590 - 30) && (gameover == 0)) {
		gameover = 1;
	}
	if (b[0] < 100 ) {
		gameover = 1;
	}
	if (gameover == 1) {
		printf("Game over! Scorul tau este: %d\n", int(angularStep));
		gameover = 2;
	}
	if (gameover == 2) {
		angularStep = 0;
		b[0] = 2000;
	}
	if (gameover == 0) {
		if (((limitx + translateX) < (a[1] + 20)) && ((limitx + translateX + 50) > a[0])) {
			if ((b[0] + 30 > limitup) || (b[0] < limitdown)) {
				aaa = int(angularStep);
				gameover = 1;
			}
		}
	}
	if (angularStep > varprint) {
		printf("Felicitari! Ai atins scorul de %d\n", varprint);
		varprint = varprint + 3;
	}
}

void Tema1::FrameEnd()
{

}

void Tema1::OnInputUpdate(float deltaTime, int mods)
{

}

void Tema1::OnKeyPress(int key, int mods)
{
	if (key == GLFW_KEY_SPACE) {
		okkk = 1;
	}
}

void Tema1::OnKeyRelease(int key, int mods)
{
	if (key == GLFW_KEY_SPACE) {
		okkk = 0;
	}
}

void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema1::OnWindowResize(int width, int height)
{
}
 